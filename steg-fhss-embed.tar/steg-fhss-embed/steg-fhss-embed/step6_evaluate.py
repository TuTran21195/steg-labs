import os
import numpy as np
from scipy.io.wavfile import read
import sys

def evaluate(original_file, stego_file):
    # So sánh kích thước file
    original_size = os.path.getsize(original_file)
    stego_size = os.path.getsize(stego_file)
    print(f"\nOriginal file size: {original_size} bytes")
    print(f"Stego file size: {stego_size} bytes")

    if original_size == stego_size:
        print("File size unchanged.")

    # So sánh mức độ khác biệt theo năng lượng trung bình (MSE)
    rate1, data1 = read(original_file)
    rate2, data2 = read(stego_file)

    if data1.shape != data2.shape:
        print("Cannot compare due to different signal sizes.")
        return

    mse = np.mean((data1.astype(np.float32) - data2.astype(np.float32)) ** 2)
    print(f"Mean Squared Error (MSE): {mse:.4f}")

    # Đánh giá MSE và in câu tương ứng
    if 0 <= mse <= 10:
        print("Very good, almost no audible difference.")
    elif 10 < mse <= 100:
        print("Still good, usually indistinguishable.")
    elif 100 < mse <= 1000:
        print("Difference may be audible depending on level.")
    else:  # mse > 1000
        print("Distortion clearly audible.")

# --------------------- MAIN ----------------------
if len(sys.argv) != 3:
    print("Hint: python3 step6_evaluate.py original_audio.wav stego_audio.wav")
    sys.exit(1)

original_file = sys.argv[1]
stego_file = sys.argv[2]

evaluate(original_file, stego_file)


import numpy as np
from scipy.io.wavfile import read
import soundfile as sf
import sys

def bits_to_text(bits):
    chars = [bits[i:i+8] for i in range(0, len(bits), 8)]
    return ''.join(chr(int(c, 2)) for c in chars if len(c) == 8)

def extract_message(signal, fs, hopping_pattern, base_freq=2000, delta=100):
    t = np.linspace(0, 0.01, int(fs * 0.01), endpoint=False)
    samples_per_symbol = len(t)

    num_bits = len(signal) // samples_per_symbol
    bits = ''

    for i in range(num_bits):
        seg = signal[i*samples_per_symbol : (i+1)*samples_per_symbol]
        hop = hopping_pattern[i]
        f0 = base_freq + hop * delta
        f1 = base_freq + (hop + 1) * delta

        corr0 = np.sum(seg * np.sin(2 * np.pi * f0 * t))
        corr1 = np.sum(seg * np.sin(2 * np.pi * f1 * t))

        bits += '0' if corr0 > corr1 else '1'

    return bits

# --- Kiểm tra tham số ---
if len(sys.argv) != 4:
    print("Hint: python3 step5_extract_message.py stego_audio.wav modulated_signal.wav hopping_pattern.txt")
    sys.exit(1)

stego_file = sys.argv[1]
mod_signal_file = sys.argv[2]
hopping_pattern_file = sys.argv[3]

# Đọc file
fs, stego_audio = read(stego_file)
stego_audio = stego_audio.astype(np.float32) / 32767  # chuẩn hóa

mod_signal, _ = sf.read(mod_signal_file, dtype='float32')
signal_length = len(mod_signal)

# Cắt phần đầu chứa thông điệp
signal = stego_audio[:signal_length]

# Đọc hopping pattern
with open(hopping_pattern_file, 'r') as f:
    hopping_pattern = [int(x) for x in f.read().strip().split()]

# Trích xuất bit
extracted_bits = extract_message(signal, fs, hopping_pattern)


print("Thông điệp đã trích xuất và lưu vào recovered_bits.txt")
print(f"ket qua tach duoc:{extracted_bits}")

# Lưu kết quả trích xuất bit
with open("recovered_bits.txt", "w") as f:
    f.write(extracted_bits)

# Chuyển bits thành văn bản
recovered_text = bits_to_text(extracted_bits)


print("Thông điệp đã trích xuất và lưu vào recovered_bits.txt và recovered_message.txt")
print("Nội dung:", recovered_text)


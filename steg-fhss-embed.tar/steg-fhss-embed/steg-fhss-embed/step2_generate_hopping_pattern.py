import random
import sys

def generate_hopping_pattern(length, hop_range=(1, 5)):
    return [random.randint(*hop_range) for _ in range(length)]

# Sinh dãy nhảy tần
if len(sys.argv) != 2:
    print("Vui lòng nhập chiều dài dãy nhảy tần. Hint: python3 step2_generate_hopping_pattern.py <chiều_dài_dãy_nhảy_tần>")
    sys.exit(1)

length = int(sys.argv[1])

hopping_pattern = generate_hopping_pattern(length)
output_file = 'hopping_pattern.txt'
with open(output_file, 'w') as f:
    f.write(" ".join(map(str, hopping_pattern)))

print(f"Dãy nhảy tần đã được tạo và lưu vào file {output_file}")

print("Dãy nhảy tần:")
print(hopping_pattern)


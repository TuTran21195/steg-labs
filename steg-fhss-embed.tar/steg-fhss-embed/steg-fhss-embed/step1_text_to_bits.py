import sys

def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)

# Đọc file message.txt
if len(sys.argv) != 2:
    print("Vui lòng nhập tên file thông điệp. Hint: python3 step1_text_to_bits.py <file-chua-ban-tin-can-giau>")
    sys.exit(1)

input_file = sys.argv[1]

with open(input_file, 'r') as f:
    message = f.read()

# Chuyển đổi thông điệp thành bit
bits = text_to_bits(message)

# Lưu chuỗi bit vào file
output_file = 'bits.txt'
with open(output_file, 'w') as f:
    f.write(bits)
print("Stored: bits.txt")
# In ra chuỗi bit
print("Thông điệp dưới dạng bit:")
print(bits)
print(f"Length:{len(bits)} bits")

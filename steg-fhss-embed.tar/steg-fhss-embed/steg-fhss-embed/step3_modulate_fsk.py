import numpy as np
import sys
import soundfile as sf

def modulate_fsk(bits, fs, base_freq=2000, delta=100, hopping_pattern=None):
    t = np.linspace(0, 0.01, int(fs * 0.01), endpoint=False)  # 10ms mỗi bit
    signal = np.array([])
    for i, bit in enumerate(bits):
        hop = hopping_pattern[i]
        if bit == '0':
            freq = base_freq + hop * delta
        else:
            freq = base_freq + (hop + 1) * delta
        tone = np.sin(2 * np.pi * freq * t)
        signal = np.concatenate((signal, tone))
    return signal

# Đọc chuỗi bit và dãy nhảy tần từ tham số
if len(sys.argv) != 3:
    print("Vui lòng nhập tên file thông điệp dạng bit và dãy nhảy tần. Hint: python3 step3_modulate_fsk.py <file_bits> <file_hopping_pattern>")
    sys.exit(1)

bits_file = sys.argv[1]
hopping_pattern_file = sys.argv[2]

with open(bits_file, 'r') as f:
    bits = f.read().strip()

with open(hopping_pattern_file, 'r') as f:
    hopping_pattern = [int(x) for x in f.read().strip().split()]

# Thực hiện điều chế FSK
fs = 44100  # Sample rate
modulated_signal = modulate_fsk(bits, fs, hopping_pattern=hopping_pattern)

#=================
modulated_signal *= 0.0005  # giảm mức ảnh hưởng lên âm thanh
#========================

# luu modulated_signal lai de chut nua combine voi original.wav
sf.write('modulated_signal.wav', modulated_signal.astype(np.float32), fs)
print("Saved: modulated_signal.wav")

print("Tín hiệu đã điều chế FSK:")
print(modulated_signal)


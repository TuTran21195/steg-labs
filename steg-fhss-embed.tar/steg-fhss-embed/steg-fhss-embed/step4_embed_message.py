import numpy as np
from scipy.io.wavfile import read, write
import sys
import soundfile as sf

def embed_message(audio, modulated_signal):
    combined = np.copy(audio)
    if len(modulated_signal) > len(audio):
        raise ValueError("Tín hiệu quá dài so với âm thanh gốc")
    combined[:len(modulated_signal)] += modulated_signal
    # CẮT BỚT nếu vượt ngưỡng [-1, 1] để tránh méo
    combined = np.clip(combined, -1.0, 1.0)
    return combined

# Đọc âm thanh gốc từ file
if len(sys.argv) != 3:
    print("Vui lòng nhập tên file âm thanh gốc và file modulated_signal. Hint: python3 step4_embed_message.py original_audio.wav stego_audio.wav")
    sys.exit(1)

audio_file = sys.argv[1]
modulated_signal_file = sys.argv[2]

fs, original_audio = read(audio_file)
original_audio = original_audio.astype(np.float32) / 32768.0  # Chuyển sang float32 & CHUẨN HÓA 

modulated_signal, fs = sf.read(modulated_signal_file, dtype='float32')

# Nhúng thông điệp vào âm thanh
message_file = 'bits.txt'
with open(message_file, 'r') as f:
    message_bits = f.read().strip()

stego_audio = embed_message(original_audio, modulated_signal)

# Lưu âm thanh đã nhúng vào file mới
output_file = 'stego_audio.wav'
write(output_file, fs, (stego_audio * 32767).astype(np.int16))  # ✅ Chuẩn hóa về int16 khi lưu
print(f"Tín hiệu đã nhúng vào {output_file}")

